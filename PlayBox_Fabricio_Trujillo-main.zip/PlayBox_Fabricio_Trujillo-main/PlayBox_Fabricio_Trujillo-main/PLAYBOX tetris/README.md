# Tetris-Game

The main branch contains the code for my Tetris Game exactly as presented in the video https://youtu.be/jcUctrLC-7M.
